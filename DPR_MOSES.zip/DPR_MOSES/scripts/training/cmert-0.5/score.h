// $Id: score.h 1307 2007-03-14 22:22:36Z hieuhoang1972 $
#ifndef SCORE_H
#define SCORE_H

extern int comps_n;

void comps_addto(int *comps1, int *comps2);
float compute_score(int *comps);

#endif
