#ifndef moses_hash_h
#define moses_hash_h

// taken from burtleburtle.net/bob/hash/doobs.html
unsigned int quick_hash(register const char *k, register unsigned int length, register unsigned int initval);

#endif

